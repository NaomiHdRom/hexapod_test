import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import ExecuteProcess, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration

from launch_ros.actions import Node
import xacro


def generate_launch_description():

    gazebo = ExecuteProcess(
        cmd=[
            'gazebo', '--verbose',
            '-s', 'libgazebo_ros_factory.so',
            os.path.join(
                get_package_share_directory('hexapod_bringup'),
                'world',
                'hexapod_world.world'
            )
        ],
        output='screen'
    )

    package_path = get_package_share_directory('hexapod_moveit_config_new')
    xacro_file = os.path.join(package_path, 'urdf', 'hexapod.ros2_control.xacro')

    doc = xacro.parse(open(xacro_file))
    xacro.process_doc(doc)
    params = {'robot_description': doc.toxml()}

    controllers_yaml = os.path.join(
        get_package_share_directory('hexapod_moveit_config_new'),
        'config',
        'ros2_controllers.yaml'
    )

    node_robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[params]
    )

    ros2_control_node = Node(
        package="controller_manager",
        executable="ros2_control_node",
        parameters=[
            params,
            controllers_yaml
        ],
        output="screen"
    )

    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-topic', 'robot_description', '-entity', 'hexapod'],
        output='screen'
    )

    moveit_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('hexapod_moveit_config_new'),
                'launch',
                'demo.launch.py'
            )
        ),
        launch_arguments={'use_sim_time': 'true'}.items()
    )

    return LaunchDescription([
        gazebo,
        node_robot_state_publisher,
        ros2_control_node,   # 🔥 antes del spawn
        spawn_entity,
        moveit_launch,
    ])

